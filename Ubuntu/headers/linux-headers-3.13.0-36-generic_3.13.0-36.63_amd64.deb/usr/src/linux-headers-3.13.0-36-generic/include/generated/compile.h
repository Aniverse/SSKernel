/* This file is auto generated, version 63-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#63-Ubuntu SMP Wed Sep 3 21:30:07 UTC 2014"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "toyol"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
