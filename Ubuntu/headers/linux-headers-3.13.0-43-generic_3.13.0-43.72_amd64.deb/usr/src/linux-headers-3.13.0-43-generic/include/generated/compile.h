/* This file is auto generated, version 72-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#72-Ubuntu SMP Mon Dec 8 19:35:06 UTC 2014"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "tipua"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
