/* This file is auto generated, version 58~14.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#58~14.04.1-Ubuntu SMP Mon Jun 22 10:21:20 UTC 2015"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "brownie"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
