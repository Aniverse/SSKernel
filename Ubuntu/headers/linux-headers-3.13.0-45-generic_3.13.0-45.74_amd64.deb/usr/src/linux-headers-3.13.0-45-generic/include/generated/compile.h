/* This file is auto generated, version 74-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#74-Ubuntu SMP Tue Jan 13 19:36:28 UTC 2015"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "phianna"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
