#define UTS_RELEASE "3.13.0-40-generic"
#define UTS_UBUNTU_RELEASE_ABI 40
