#define UTS_RELEASE "3.13.0-37-generic"
#define UTS_UBUNTU_RELEASE_ABI 37
