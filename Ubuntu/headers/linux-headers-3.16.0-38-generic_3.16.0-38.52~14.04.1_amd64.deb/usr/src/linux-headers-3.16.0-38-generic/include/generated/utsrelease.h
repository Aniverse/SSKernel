#define UTS_RELEASE "3.16.0-38-generic"
#define UTS_UBUNTU_RELEASE_ABI 38
