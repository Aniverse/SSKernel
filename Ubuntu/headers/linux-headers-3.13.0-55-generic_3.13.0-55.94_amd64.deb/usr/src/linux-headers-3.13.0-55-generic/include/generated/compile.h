/* This file is auto generated, version 94-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#94-Ubuntu SMP Thu Jun 18 00:27:10 UTC 2015"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "brownie"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
