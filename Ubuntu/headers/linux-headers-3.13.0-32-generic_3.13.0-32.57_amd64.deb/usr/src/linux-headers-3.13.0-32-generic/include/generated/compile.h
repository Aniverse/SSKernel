/* This file is auto generated, version 57-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#57-Ubuntu SMP Tue Jul 15 03:51:08 UTC 2014"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "kissel"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
